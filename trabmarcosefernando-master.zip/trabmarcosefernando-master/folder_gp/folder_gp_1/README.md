# Atividade - Menu

`./exec.py` -> Execute-o para iniciar a aplicação;


##### Realizado pelo grupo relativo à movimentação

3° B

ETEC TABOÃO

## Integrantes

Andrei Peçanha
 
Otávio Magalhães
  
Vitor Ferreira
 
Giovanna Aparecida
 
Nicholas Misael
 
Catarina Vieira 

Isabela Borges
 
Diogo Souza

Caio Schissatii

Luan Ferreira
 
Filipe Marques

Gustavo Henrique